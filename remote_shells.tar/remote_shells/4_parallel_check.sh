server_list_file="sshfiles.txt"
tmux_session_name="0"  # 现有的tmux会话名称

# 逐行读取服务器IP地址并执行命令
while read -r server_ip; do
    # 在服务器上执行命令，连接到现有的tmux会话和窗口
    echo "Executing on server: $server_ip \n"
    ssh -n $server_ip "nvidia-smi"
    # ssh -n $server_ip "ls ~/Chinese-Llama-2-7b/checkpoints_llama2/checkpoint-500"
    # ssh -n $server_ip "nvcc -V"
    # ssh -n $server_ip "cp -r /home/xmu/Chinese-Llama-2-7b/checkpoints_llama2/* /mnt/store/llama2-checkpoints"
    # ssh -n $server_ip "ls /mnt/store"
    # ssh -n $server_ip 'tmux new-session -d -s 0'
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'conda activate Colossalai' Enter"
done < "$server_list_file"
