server_list_file="sshfiles.txt"
tmux_session_name="0"  # 现有的tmux会话名称

# 逐行读取服务器IP地址并执行命令
count=0

while read -r server_ip; do
    # 在服务器上执行命令，连接到现有的tmux会话和窗口
    echo ""
    echo "Executing on server: $server_ip"
    echo ""
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'conda activate chllama2' Enter"
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'cd ~/Chinese-Llama-2-7b-plus' Enter"
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'sh run.sh' Enter"
    count=$((count + 1))
done < "$server_list_file"

echo ""
