server_list_file="sshfiles.txt"
tmux_session_name="0"  # 现有的tmux会话名称

# 逐行读取服务器IP地址并执行命令
count=0

while read -r server_ip; do
    # 在服务器上执行命令，连接到现有的tmux会话和窗口
    echo ""
    echo "Executing on server: $server_ip"
    echo ""
    ssh -n $server_ip "cp -r /mnt/store/Chinese-Llama-2-7b-plus/run_sft.sh          ~/Chinese-Llama-2-7b-plus"
    ssh -n $server_ip "echo 'NODE_RANK=$count' | cat - ~/Chinese-Llama-2-7b-plus/run_sft.sh >> tmp.txt && mv tmp.txt ~/Chinese-Llama-2-7b-plus/run_sft.sh"
    ssh -n $server_ip "cp -r /mnt/store/Chinese-Llama-2-7b-plus/train_base.py       ~/Chinese-Llama-2-7b-plus"
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'conda activate chllama2' Enter"
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'cd ~/Chinese-Llama-2-7b-plus' Enter"
    count=$((count + 1))
done < "$server_list_file"

echo ""