server_list_file="sshfiles.txt"
tmux_session_name="0"  # 现有的tmux会话名称
command_to_execute="sudo -S pkill colossalai <<< XMUMac2023"  # 要在tmux中执行的命令

# 逐行读取服务器IP地址并执行命令
while read -r server_ip; do
    # 在服务器上执行命令，连接到现有的tmux会话和窗口
    echo ""
    echo "Executing on server: $server_ip"
    echo ""
    ssh -n $server_ip "sudo -S pkill torchrun <<< XMUMac2023"
    ssh -n $server_ip "sudo -S pkill python <<< XMUMac2023"
done < "$server_list_file"

echo ""