server_list_file="sshfiles.txt"
tmux_session_name="0"  # 现有的tmux会话名称

# 逐行读取服务器IP地址并执行命令
while read -r server_ip; do
    # 在服务器上执行命令，连接到现有的tmux会话和窗口
    echo ""
    echo "Executing on server: $server_ip"
    echo ""
    # ssh -n $server_ip "cp -r /mnt/store/Chinese-Llama-2-7b-plus ~"
    # ssh -n $server_ip "tmux new -s 0"
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'conda activate Colossalai' Enter"
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'rm ~/Chinese-Llama-2-7b-plus' Enter"
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'cp -r /mnt/store/Chinese-Llama-2-7b-plus ~' Enter"
    ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'FLASH_ATTENTION_FORCE_BUILD=TRUE pip install -U flash-attn' Enter"
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'sudo -S rm -rf ~/anaconda3/envs/chllama2 <<< XMUMac2023' Enter"
    # ssh -n $server_ip "tmux send-keys -t $tmux_session_name 'cp -r /mnt/store/chllama2 ~/anaconda3/envs/' Enter"
    
done < "$server_list_file"

echo ""